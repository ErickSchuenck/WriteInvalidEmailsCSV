const Knex = require("knex");

const connection = Knex({
  client: "pg",
  connection: {
    ssl: false,
    host: "127.0.0.1",
    user: "postgres",
    password: "postgres",
    database: "libertas",
  },
});

module.exports = { connection };
