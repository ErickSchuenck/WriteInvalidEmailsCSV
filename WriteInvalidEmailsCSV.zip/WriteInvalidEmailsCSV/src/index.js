const { default: axios } = require("axios");
const { connection } = require("./config/database");
const { createObjectCsvWriter } = require("csv-writer");
const path = require("path");

const generateCurrentDateFormat = () => {
  return new Date()
    .toLocaleString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
    .replace(/\/|,|\s|:/g, "-");
};

const verifyEmailInValidator = async (email) => {
  const URL = `https://func-emailvalidator-prod-eastus-001.azurewebsites.net/api/email-validator?email=${encodeURIComponent(
    email
  )}&code=gCqxvXQf_QXjpckji-tcslObRJVdUb6ABEUYMgcvN1X1AzFu2GpCtQ%3D%3D`;

  return axios
    .get(URL)
    .then((response) => {
      console.log(email, response.data.isValid);
      return {
        isValid: response.data.isValid,
        message: null,
      };
    })
    .catch((error) => {
      const errorMessage = error.response?.data?.message;
      console.log(email, errorMessage);
      if (errorMessage) {
        return {
          isValid: false,
          message: errorMessage,
        };
      } else {
        throw error;
      }
    });
};

const findInvalidEmails = async () => {
  const accountContacts = await connection("accountContact")
    .select("*")
    .from("accountContact")
    .where("contactType", "=", "EMAIL");
  // .limit(1);
  // limite para testar o script

  const invalidEmails = [];
  for (const account of accountContacts) {
    const email = account.contact.replace(" ", "");

    const { isValid, message } = await verifyEmailInValidator(email);
    if (!isValid) {
      invalidEmails.push({ ...account, message });
    }
  }

  return invalidEmails;
};

const generateFilename = () => {
  return `accounts_${generateCurrentDateFormat()}.csv`;
};

const generateHeader = (accounts) => {
  const keys = Object.keys(accounts[0]);
  return keys.map((key) => ({ id: key, title: key }));
};

const generateCSV = async () => {
  const startTime = new Date();

  console.log(
    `Generating your csv, this may take a while. Starting at ${startTime}`
  );

  const accounts = await findInvalidEmails();
  const directoryPath = "./register";
  const fileName = generateFilename();
  const filePath = path.join(directoryPath, fileName);

  if (accounts.length === 0) {
    console.log("There are no invalid emails");
  }

  //montar objeto csv
  const csvWriter = createObjectCsvWriter({
    path: filePath,
    header: generateHeader(accounts),
  });

  // criar csv
  await csvWriter.writeRecords(accounts);

  //cronometrar tempo
  const endTime = new Date();
  const elapsedTime = (endTime - startTime) / 1000;

  console.log(
    `🚀 CSV file has been created at ${filePath} in ${elapsedTime} with the retrieved data. You may now close this terminal 🚀`
  );
};

generateCSV();
